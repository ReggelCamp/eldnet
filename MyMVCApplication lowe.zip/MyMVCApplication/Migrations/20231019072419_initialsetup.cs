﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MyMVCApplication.Migrations
{
    /// <inheritdoc />
    public partial class initialsetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Courses",
                columns: table => new
                {
                    CourseCode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CourseName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courses", x => x.CourseCode);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StudentFname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentMname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentLname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentYear = table.Column<int>(type: "int", nullable: false),
                    StudentRemarks = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentStatus = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentID);
                });

            migrationBuilder.CreateTable(
                name: "Subjects",
                columns: table => new
                {
                    SubjectCode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    SubjectDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectUnits = table.Column<int>(type: "int", nullable: false),
                    SubjectRegOff = table.Column<int>(type: "int", nullable: false),
                    SubjectCat = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectStatus = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectCourseCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectCurrCode = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Subjects", x => x.SubjectCode);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Courses");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Subjects");
        }
    }
}
