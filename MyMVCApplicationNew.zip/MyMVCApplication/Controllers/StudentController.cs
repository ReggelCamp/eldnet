﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyMVCApplication.Data;
using MyMVCApplication.Models;

namespace MyMVCApplication.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        public StudentController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult Index()
        {
            var student = _dbContext.Students.ToList();
            return View(student);

        }

        //PublicClientApplication IActionResult
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        [ActionName("Add")]

        public IActionResult Add(Student addRequestStudent)
        {
            var student = new Student()
            {
                StudentID= addRequestStudent.StudentID,
                StudentFname = addRequestStudent.StudentFname,
                StudentLname = addRequestStudent.StudentLname,
                StudentMname= addRequestStudent.StudentMname,
                StudentYear=addRequestStudent.StudentYear,
                StudentRemarks=addRequestStudent.StudentRemarks,
                StudentStatus= "AC",
                StudentCourse = addRequestStudent.StudentCourse,
            };

            _dbContext.Students.Add(student);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }

    }
