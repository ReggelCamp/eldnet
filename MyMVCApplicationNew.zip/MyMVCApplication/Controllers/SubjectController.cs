﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using MyMVCApplication.Data;
using MyMVCApplication.Models;

namespace MyMVCApplication.Controllers
{
    public class SubjectController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SubjectController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            {
                var subject = _context.Subjects.ToList();
                return View(subject);
            }

        }
            //PublicClientApplication IActionResult
            [HttpGet]
            public IActionResult Add()
        { 
            return View();
        }
        [HttpPost]
        [ActionName("Add")]

        public IActionResult Add(Subject addRequestSubject) { 
            var subject = new Subject() { 
                
                SubjectCode = addRequestSubject.SubjectCode,
                SubjectDescription = addRequestSubject.SubjectDescription,
                SubjectUnits = addRequestSubject.SubjectUnits,
                SubjectRegOff= addRequestSubject.SubjectRegOff,
                SubjectCat = addRequestSubject.SubjectCat,
                SubjectCourseCode = addRequestSubject.SubjectCourseCode,
                SubjectStatus = "AC",
                SubjectCurrCode = addRequestSubject.SubjectCurrCode,
            };

            _context.Subjects.Add(subject);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
