﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyMVCApplication.Models
{
    public class Subject
    {
        [Key]
        public string? SubjectCode { get; set; }
        [Required]

        public string SubjectDescription { get; set; } = string.Empty;
        [Required]

        public int SubjectUnits { get; set; }

        [Required]
        public int SubjectRegOff { get; set; }

        [Required]
        public string? SubjectCat { get; set; }

        [Required]
        public string? SubjectStatus{ get; set; }

       // [ForeignKey("SubjectCourseCode")]
        public string? SubjectCourseCode { get; set; }

        [Required]
        public string SubjectCurrCode { get; set;}
    }
}
