﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyMVCApplication.Data;
using MyMVCApplication.Models;
using System.Net.NetworkInformation;

namespace MyMVCApplication.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        public StudentController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult Index()
        {
            var student = _dbContext.Students.ToList();
            return View(student);

        }

        //PublicClientApplication IActionResult
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        [ActionName("Add")]

        public IActionResult Add(Student addRequestStudent)
        {
            if (_dbContext.Students.Any(s => s.StudentID == addRequestStudent.StudentID))
            {
                TempData["DuplicateError"] = "A student with the same ID number already exists.";
                return View(addRequestStudent); // Return to the form with the error message
            }

            if (ModelState.IsValid)
            {
                var student = new Student()
                {
                    StudentID = addRequestStudent.StudentID,
                    StudentFname = addRequestStudent.StudentFname,
                    StudentLname = addRequestStudent.StudentLname,
                    StudentMname = addRequestStudent.StudentMname,
                    StudentYear = addRequestStudent.StudentYear,
                    StudentRemarks = addRequestStudent.StudentRemarks,
                    StudentStatus = "AC",
                    StudentCourse = addRequestStudent.StudentCourse,
                };

                _dbContext.Students.Add(student);
                _dbContext.SaveChanges();
                return RedirectToAction("Index");

                TempData["SuccessMessage"] = "Student added successfully.";
                return RedirectToAction("Index");
            }
            else
            {
                TempData["FieldError"] = "Please fill out all required fields.";
                return View(addRequestStudent);
            }
        }

        //edit and delete

        public IActionResult Delete(string id)
        {
            var student = _dbContext.Students.FirstOrDefault(s => s.StudentID == id);
            if (student != null)
            {
                _dbContext.Students.Remove(student);
                _dbContext.SaveChanges();
            }
            return RedirectToAction("Index");

        }
        public IActionResult Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var studentToEdit = _dbContext.Students.FirstOrDefault(s => s.StudentID == id);

            if (studentToEdit != null)
            {
                return NotFound();
            }
            return View(studentToEdit);

        }


        [HttpPost]
        public IActionResult Edit(Student Edittedstudent)
        {
            //if (ModelState.IsValid)
            //{
                var Currentstudent = _dbContext.Students.FirstOrDefault(stud => stud.StudentID == Edittedstudent.StudentID);
                if (Currentstudent != null)
                {
                    Currentstudent.StudentID = Edittedstudent.StudentID;
                    Currentstudent.StudentFname = Edittedstudent.StudentFname;
                    Currentstudent.StudentMname = Edittedstudent.StudentMname;
                    Currentstudent.StudentLname = Edittedstudent.StudentLname;
                    Currentstudent.StudentCourse = Edittedstudent.StudentCourse;
                    Currentstudent.StudentStatus = Edittedstudent.StudentStatus;
                    Currentstudent.StudentRemarks = Edittedstudent.StudentRemarks;
                    Currentstudent.StudentYear = Edittedstudent.StudentYear;
                    //Currentstudent.Student.Update(Currentstudent);
                    //Currentstudent.SaveChanges();

                    _dbContext.SaveChanges();
                    return RedirectToAction("Index");
                }
                //else
                //{
                //    return NotFound();
                //}

            //}

            return View(Edittedstudent);


            // end
        }
    }
}


   
//public IActionResult Delete(string id)
//    {
//        var subject = _dbContext.Subjects.FirstOrDefault(s => s.SubjectCode == id);
//        if (subject != null)
//        {
//            _dbContext.Subjects.Remove(subject);
//            _dbContext.SaveChanges();
//        }
//        return RedirectToAction("Index");

//    }
//    public IActionResult Edit(string id)
//    {
//        var subject = _dbContext.Subjects.FirstOrDefault(s => s.SubjectCode == id);
//        if (subject != null)
//        {
//            return View(subject);
//        }
//        return View();

//    }

//    [HttpPost]
//    public IActionResult Edit(Subject subject)
//    {
//        if (subject == null)
//        {
//            return View();
//        }
//        if (ModelState.IsValid)
//        {
//            _dbContext.Subjects.Update(subject);
//            _dbContext.SaveChanges();
//            return RedirectToAction("Index");
//        }
//        return View(subject);