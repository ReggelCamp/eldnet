﻿using System.ComponentModel.DataAnnotations;

namespace MyMVCApplication.Models
{
    public class Course
    {
        [Key]
        public string? CourseCode { get; set; }
        public string? CourseName { get;set; }
    }
}
