﻿using System.ComponentModel.DataAnnotations;

namespace MyMVCApplication.Models
{
    public class Student
    {
        [Key]
        public string? StudentID { get; set; }

        [Required]
        public string ?StudentFname { get; set; }

        [Required]
        public string ?StudentMname { get; set;}

        [Required]
        public string ?StudentLname { get; set; } = string.Empty;

        [Required]
        public int StudentYear { get; set; }

        [Required]
        public string ?StudentRemarks { get; set; }

        [Required]
        public string? StudentStatus { get; set;}

        [Required]
        public string? StudentCourse { get; set; }

    }
}
